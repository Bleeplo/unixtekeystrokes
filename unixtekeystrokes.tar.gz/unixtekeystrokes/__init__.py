import subprocess as sp, time, pyxhook

def keystroke(key, time_delay): # presses a key
    """
    Tell unixtekeystrokes to press a key for you

    :param key: Put in a key letter that you would like to have a fake keystroke of. Example, keystroke('w', 0), it would type/press w.\n
    :param time_delay: time_delay is the time (seconds) delay in the beginning when you tell the keystroke to do it's command. Example, keystroke('w', 3), it would wait 3 seconds, then type/stroke w
    """
    keycommand = "xte", "key " + key
    time.sleep(time_delay)
    sp.Popen(keycommand)

def keydown(key, time_delay): # presses a key
    """
    Tell unixtekeystrokes to hold down a key

    :param key: Put in a key letter that you would like to have a fake keystroke of. Example, keydown('w', 0), it would type/press w down.\n
    """
    keycommand = "xte", "keydown " + key
    time.sleep(time_delay)
    sp.Popen(keycommand)

def keyup(key, time_delay): # presses a key
    """
    Tell unixtekeystrokes to release a key

    :param key: Put in a key letter that you would like to have a fake keystroke of. Example, keyup('w', 0), it would release w.\n
    """
    keycommand = "xte", "keyup " + key
    time.sleep(time_delay)
    sp.Popen(keycommand)

def typewriter(sentence): # tpyes a sentence
    """
    Tell unixtekeystrokes to type out a sentence for you

    :param sentence: The sentence you tell uni to type. Example: typewriter('the quick brown fox jumped over the lazy dog.')
    """
    xtecommand = "xte", "str " + sentence
    sp.Popen(xtecommand)

def mousemove(x_cord, y_cord): # moves mouse to x,y cord
    """
    Tell unixtekeystrokes to move the mouse to a cordinate on your screen. And example of using this would be to mousemove(90, 80). It would move your mouse to the cordinate 90, 80 on your screen.

    :param x_cord: The x cordinate on your screen goes here.\n
    :param y_cord: The y cordinate on your screen goes here.
    """
    xtecommand = "xte", "mousemove " + str(x_cord) + " " + str(y_cord)
    sp.Popen(xtecommand)

def mouserel(x_cord, y_cord): # moves mouse relativley x,y-pixels away from current mouse cords
    """
    Tell unixtekeystrokes to move the mouse x & y number of pixels/cordinates away from your current mouse position. Example. mouserel(50, 70). It would move your mouse 50 pixels on the x-axis & 70 pixels on the y-axis from your current mouse position.

    :param x_cord: The amount of pixels you want to move your mouse on the x-axis.\n
    :param y_cord: The amount of pixels you want to move your mouse on the y-axis.
    """
    xtecommand = "xte", "mousermove " + str(x_cord) + " " + str(y_cord)
    sp.Popen(xtecommand)

### 1 = left click  2 = mouse-wheel-    3 = right click
def lmouseclick(): # left click
    """
    Tell unixtekeystrokes to left-click
    """
    xtecommand = "xte", "mouseclick 1"
    sp.Popen(xtecommand)

def mmouseclick(): # middle-mouse-button click.
    """
    Tell unixtekeystrokes to press the middle-mouse-button ( mouse wheel )
    """
    xtecommand = "xte", "mouseclick 2"
    sp.Popen(xtecommand)

def rmouseclick(): # right click
    """
    Tell unixtekeystrokes to right-click
    """
    xtecommand = "xte", "mouseclick 3"
    sp.Popen(xtecommand)

### Thank you ( https://stackoverflow.com/questions/38816861/how-can-i-capture-a-key-press-key-logging-in-linux ) for the code! <3
def onkeypress_keystroke(asci_keycode, key, time_delay):
    """
    Tell unixtekeystrokes to do a keystroke when a key is pressed

    :param asci_keycode: The Chr() code that represents the key that when pressed, triggers a macro/sequence event.
    """
    def keylisten(event):
        if event.Ascii == asci_keycode: # if user presses key that is correspondant to asci-code. Then it will peform action
            keydown(key, time_delay)
            keyup(key, time_delay)
            exit(0)
            
    hm = pyxhook.HookManager()
    hm.KeyDown = keylisten

    hm.HookKeyboard()
    # start's listening
    hm.start()

def onkeypress_lmouseclick(asci_keycode):
    """
    Tell unixtekeystrokes to left click when a key is pressed

    :param asci_keycode: The Chr() code that represents the key that when pressed, triggers a macro/sequence event.
    """
    def keylisten(event):
        if event.Ascii == asci_keycode: # if user presses key that is correspondant to asci-code. Then it will peform action
            lmouseclick()
            exit(0)
            
    hm = pyxhook.HookManager()
    hm.KeyDown = keylisten

    hm.HookKeyboard()
    # start's listening
    hm.start()

def onkeypress_mmouseclick(asci_keycode):
    """
    Tell unixtekeystroke to middle-mouse-button when a key is pressed
    :param asci_keycode: The Chr() code that represents the key that when pressed, triggers a macro/sequence event.
    """
    def keylisten(event):
        if event.Ascii == asci_keycode: # if user presses key that is correspondant to asci-code. Then it will peform action
            mmouseclick()
            exit(0)
            
    hm = pyxhook.HookManager()
    hm.KeyDown = keylisten

    hm.HookKeyboard()
    # start's listening
    hm.start()

def onkeypress_rmouseclick(asci_keycode):
    """
    Tell unixtekeystrokes to right click when a key is pressed
    :param asci_keycode: The Chr() code that represents the key that when pressed, triggers a macro/sequence event.
    """
    def keylisten(event):
        if event.Ascii == asci_keycode: # if user presses key that is correspondant to asci-code. Then it will peform action
            rmouseclick()
            exit(0)
            
    hm = pyxhook.HookManager()
    hm.KeyDown = keylisten

    hm.HookKeyboard()
    # start's listening
    hm.start()

def onkeypress_mousemove(asci_keycode, x_cord, y_cord):
    """
    Tell unixtekeystrokes to move the mouse to a certain cordinate when a key is pressed
    :param asci_keycode: The Chr() code that represents the key that when pressed, triggers a macro/sequence event.
    """
    def keylisten(event):
        if event.Ascii == asci_keycode: # if user presses key that is correspondant to asci-code. Then it will peform action
            mousemove(x_cord, y_cord)
            exit(0)
            
    hm = pyxhook.HookManager()
    hm.KeyDown = keylisten

    hm.HookKeyboard()
    # start's listening
    hm.start()

def onkeypress_mouserel(asci_keycode, x_cord, y_cord):
    """
    Tell unixtekeystrokes to move the mouse relative to it's current position
    :param asci_keycode: The Chr() code that represents the key that when pressed, triggers a macro/sequence event.
    """
    def keylisten(event):
        if event.Ascii == asci_keycode: # if user presses key that is correspondant to asci-code. Then it will peform action
            mouserel(x_cord, y_cord)
            exit(0)
            
    hm = pyxhook.HookManager()
    hm.KeyDown = keylisten

    hm.HookKeyboard()
    # start's listening
    hm.start()

# Multi key function
def multionkeypress_keystroke(asci_keycode, kill_key, key, time_delay):
    """
    Tell unixtekeystrokes to do a keystroke when a key is pressed

    :param asci_keycode: The Chr() code that represents the key that when pressed, triggers a macro/sequence event.
    :param kill_key: The Chr() code that represents the key that when pressed. Kills the listening for keystrokes
    """
    def keylisten(event):
        if event.Ascii == kill_key: # if user presses key that is correspondant to asci-code. Then it will peform action
            exit(0)
        if event.Ascii == asci_keycode: # if user presses key that is correspondant to asci-code. Then it will peform action
            keydown(key, time_delay)
            keyup(key, time_delay)
            
    hm = pyxhook.HookManager()
    hm.KeyDown = keylisten

    hm.HookKeyboard()
    # start's listening
    hm.start()

def multionkeypress_lmouseclick(asci_keycode, kill_key):
    """
    Tell unixtekeystrokes to left click when a key is pressed.

    :param asci_keycode: The Chr() code that represents the key that when pressed, triggers a macro/sequence event.
    :param kill_key: The Chr() code that represents the key that when pressed. Kills the listening for keystrokes
    """
    def keylisten(event):
        if event.Ascii == kill_key: # if user presses key that is correspondant to asci-code. Then it will peform action
            exit(0)
        if event.Ascii == asci_keycode: # if user presses key that is correspondant to asci-code. Then it will peform action
            lmouseclick()
            
    hm = pyxhook.HookManager()
    hm.KeyDown = keylisten

    hm.HookKeyboard()
    # start's listening
    hm.start()

def multionkeypress_mmouseclick(asci_keycode, kill_key):
    """
    Tell unixtekeystrokes to middle mouse click when a key is pressed

    :param asci_keycode: The Chr() code that represents the key that when pressed, triggers a macro/sequence event.
    :param kill_key: The Chr() code that represents the key that when pressed. Kills the listening for keystrokes
    """
    def keylisten(event):
        if event.Ascii == kill_key: # if user presses key that is correspondant to asci-code. Then it will peform action
            exit(0)
        if event.Ascii == asci_keycode: # if user presses key that is correspondant to asci-code. Then it will peform action
            mmouseclick()
            
    hm = pyxhook.HookManager()
    hm.KeyDown = keylisten

    hm.HookKeyboard()
    # start's listening
    hm.start()

def multionkeypress_rmouseclick(asci_keycode, kill_key):
    """
    Tell unixtekeystrokes to right click when a key is pressed

    :param asci_keycode: The Chr() code that represents the key that when pressed, triggers a macro/sequence event.
    :param kill_key: The Chr() code that represents the key that when pressed. Kills the listening for keystrokes
    """
    def keylisten(event):
        if event.Ascii == kill_key: # if user presses key that is correspondant to asci-code. Then it will peform action
            exit(0)
        if event.Ascii == asci_keycode: # if user presses key that is correspondant to asci-code. Then it will peform action
            rmouseclick()
            
    hm = pyxhook.HookManager()
    hm.KeyDown = keylisten

    hm.HookKeyboard()
    # start's listening
    hm.start()

def multionkeypress_mousemove(asci_keycode, kill_key, x_cord, y_cord):
    """
    Tell unixtekeystrokes to move the mouse to a cordinate when a key is pressed

    :param asci_keycode: The Chr() code that represents the key that when pressed, triggers a macro/sequence event.
    :param kill_key: The Chr() code that represents the key that when pressed. Kills the listening for keystrokes
    """
    def keylisten(event):
        if event.Ascii == kill_key: # if user presses key that is correspondant to asci-code. Then it will peform action
            exit(0)
        if event.Ascii == asci_keycode: # if user presses key that is correspondant to asci-code. Then it will peform action
            mousemove(x_cord, y_cord)
            
    hm = pyxhook.HookManager()
    hm.KeyDown = keylisten

    hm.HookKeyboard()
    # start's listening
    hm.start()

def multionkeypress_mouserel(asci_keycode,kill_key, x_cord, y_cord):
    """
    Tell unixtekeystrokes to move the mouse relative to a cordinate when a key is pressed

    :param asci_keycode: The Chr() code that represents the key that when pressed, triggers a macro/sequence event.
    :param kill_key: The Chr() code that represents the key that when pressed. Kills the listening for keystrokes
    """
    def keylisten(event):
        if event.Ascii == kill_key: # if user presses key that is correspondant to asci-code. Then it will peform action
            exit(0)
        if event.Ascii == asci_keycode: # if user presses key that is correspondant to asci-code. Then it will peform action
            mouserel(x_cord, y_cord)
            
    hm = pyxhook.HookManager()
    hm.KeyDown = keylisten

    hm.HookKeyboard()
    # start's listening
    hm.start()